﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodTimeStudio.OneMinecraftLauncher.Core.Models
{
    public class LauncherLoginAuthenticationModel
    {
        public string name;
        public string password;
    }
}
